# MIKOS Launcher 5G (Kotlin + Jetpack Compose)

## Install
1. Android Studio me `MIKOS` folder open karo, ya GitHub Actions se APK banao (.github/workflows/build.yml). GitHub Actions me `MIKOS_SERVER` repository variable ko deployed server ke HTTPS base address par set karo (last `/` ke bina); bina iske AI/Game Engine server se connect nahi hoga.
2. Install karke Home dabao -> MIKOS -> Always.
(targetSdk 28 hai taaki Wi-Fi/Bluetooth direct toggle ho sake. Ye APK sideload ke liye hai, Play Store ke liye nahi.)

## Pehli baar setup
- MIKOS AI: AI app kholo -> gear icon -> MIKOS access key daalo (admin se milti hai). Koi API key nahi chahiye. Bina key ke offline demo chalta hai.
- Pehle AiChat.kt me MIKOS_SERVER ko apne server ke address se badlo (MIKOS-Admin folder dekho).
- Notification access: Settings app -> Notification access -> allow
- Phone/Messages/Gallery kholte hi permission maangte hain

## MIKOS AI
- Real streaming chat (MIKOS server ke through), multi-turn memory, coding help
- Code blocks with copy button, bold/inline-code markdown
- Voice input, stop button, new chat, chat history save hoti hai
- Model aur system prompt settings me badal sakte ho

## Wi-Fi / Bluetooth
- Control Center aur Settings me tile/row dabao -> direct on/off ki koshish
- Agar phone/OS block kare to system panel/settings khul jata hai

## Baaki features
Lock screen (fingerprint/PIN), real notifications + music controls, Dynamic Island, real status bar,
brightness/volume sliders, torch, Phone (contacts, call log, calling), Messages (SMS), Gallery,
Clock, Notes, Calculator, 5G Speed Test, Weather (sheher badal sakte ho), App Library.

## Camera (MIKOS ke andar)
- CameraX live preview, pinch zoom, tap focus, exposure slider, flash, front/back
- Modes: Auto, HDR, Night, Portrait (phone ka hardware AI mode agar available, warna software AI), Moon
- AI Scene (sparkle button): Claude vision se scene pehchan + tips (MIKOS access key chahiye)
- Moon mode: zoom + kam exposure, moon dhoondh kar crop, upscale, sharpen. Koi nakli texture nahi lagti
- Photo 95% JPEG me Pictures/MIKOS me save hoti hai (Gallery me dikhti hai)

## MIKOS Game Engine (Games app)
- Idea likho (jaise "space shooter jisme boss ho"), AI poora playable game bana deta hai aur app ke andar chalata hai
- Touch controls, joystick, tilt, particles, sounds, high score: sab MK engine runtime se (server inject karta hai)
- "AI se badlo" se game me changes karwa sakte ho; games phone me save hoti hain (max 15)
- Sirf valid MIKOS access key wale users chala sakte hain. API key admin panel me set hoti hai, app me nahi.

## MIKOS 3D Engine Studio (Games app ke andar)
- Games app me "3D Engine Studio" button. Engine file: `app/src/main/assets/engine3d.html` (three.js, CDN se; internet chahiye).
- Scripting: C# aur Java (chhota subset, JS me convert hota hai) + Blueprint (visual nodes). Code phone me save hota hai.
- Asset import: .glb / .obj (3D model), .png / .jpg (texture), .mp3 / .wav (sound). .glb sabse best.
- AI button: idea likho, AI chuni hui language me script bana deta hai. Server ka `/api/script` endpoint chahiye (MIKOS-Admin/server.js me hai); access key Games app me save honi chahiye.
