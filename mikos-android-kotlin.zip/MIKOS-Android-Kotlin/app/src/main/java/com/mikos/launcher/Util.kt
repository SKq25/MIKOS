package com.mikos.launcher

import android.content.*
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import androidx.compose.foundation.shape.RoundedCornerShape
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// Sheher ab Weather app ke andar se badalta hai (Store.city)
val CITY: String get() = Store.city

data class App(val label: String, val pkg: String, val icon: ImageBitmap)

fun loadApps(c: Context): List<App> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != c.packageName }
        .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun Context.go(i: Intent) {
    try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { Toast.makeText(this, "Ye feature is device par nahi mila", Toast.LENGTH_SHORT).show() }
}

fun Context.launchPkg(pkg: String) {
    val i = packageManager.getLaunchIntentForPackage(pkg)
    if (i != null) go(i) else Toast.makeText(this, "App nahi mila", Toast.LENGTH_SHORT).show()
}

fun Modifier.glass(r: Dp = 22.dp): Modifier {
    val s = RoundedCornerShape(r)
    return this
        .shadow(10.dp, s, clip = false, ambientColor = Color(0x664A7BFF), spotColor = Color(0x664A7BFF))
        .clip(s)
        .background(Brush.linearGradient(listOf(Color(0xB3162262), Color(0x990A0A2A))))
        .border(1.dp, Brush.verticalGradient(listOf(Color(0x99FFFFFF), Color(0x336EA0FF))), s)
}

object TorchCtl {
    var on by mutableStateOf(false)
    fun toggle(c: Context) {
        on = !on
        try {
            val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id != null) cm.setTorchMode(id, on)
        } catch (_: Exception) {}
    }
}

@Composable fun now(): Date {
    var d by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { d = Date(); delay(1000) } }
    return d
}

@Composable fun battery(): Int {
    val c = LocalContext.current
    var b by remember { mutableIntStateOf(100) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(x: Context, i: Intent) {
                b = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                Stat.charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            }
        }
        c.registerReceiver(r, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        onDispose { c.unregisterReceiver(r) }
    }
    return b
}

// ---------------- Weather (Open-Meteo, free, no API key) ----------------
data class Day(val name: String, val hi: Int, val lo: Int, val code: Int)
data class Weather(val temp: Int, val code: Int, val days: List<Day>)
object Stat { var charging by mutableStateOf(false) }

@Composable fun netInfo(): Pair<Boolean, String> {
    val c = LocalContext.current
    var r by remember { mutableStateOf(false to "") }
    LaunchedEffect(Unit) {
        while (true) {
            try {
                val cm = c.getSystemService(ConnectivityManager::class.java)
                val caps = cm.getNetworkCapabilities(cm.activeNetwork)
                val wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                val op = (c.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).networkOperatorName
                r = wifi to (if (wifi) "Wi-Fi" else if (caps != null) op.ifBlank { "Mobile" } else "No network")
            } catch (_: Exception) {}
            delay(3000)
        }
    }
    return r
}

object Store {
    var weather by mutableStateOf<Weather?>(null)
    var city by mutableStateOf("Dehradun")
    var lat = 30.3165
    var lon = 78.0322
}

fun loadCity(c: Context) {
    val sp = c.getSharedPreferences("mikos", Context.MODE_PRIVATE)
    Store.city = sp.getString("city", "Dehradun") ?: "Dehradun"
    Store.lat = sp.getFloat("lat", 30.3165f).toDouble()
    Store.lon = sp.getFloat("lon", 78.0322f).toDouble()
}

suspend fun setCity(c: Context, name: String): Boolean = withContext(Dispatchers.IO) {
    try {
        val u = "https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + java.net.URLEncoder.encode(name, "UTF-8")
        val conn = URL(u).openConnection() as HttpURLConnection
        conn.connectTimeout = 6000; conn.readTimeout = 6000
        val r = JSONObject(conn.inputStream.bufferedReader().readText()).optJSONArray("results")
        if (r == null || r.length() == 0) false else {
            val o = r.getJSONObject(0)
            Store.city = o.getString("name"); Store.lat = o.getDouble("latitude"); Store.lon = o.getDouble("longitude")
            c.getSharedPreferences("mikos", Context.MODE_PRIVATE).edit()
                .putString("city", Store.city).putFloat("lat", Store.lat.toFloat()).putFloat("lon", Store.lon.toFloat()).apply()
            true
        }
    } catch (_: Exception) { false }
}

fun wxVec(c: Int): ImageVector = when (c) { 0 -> Icons.Filled.WbSunny; 1, 2 -> Icons.Filled.FilterDrama; 3 -> Icons.Filled.Cloud; 45, 48 -> Icons.Filled.Dehaze; in 51..67 -> Icons.Filled.Grain; in 71..77 -> Icons.Filled.AcUnit; in 80..82 -> Icons.Filled.Grain; in 95..99 -> Icons.Filled.Thunderstorm; else -> Icons.Filled.WbCloudy }
fun wxText(c: Int) = when (c) { 0 -> "Clear"; 1, 2 -> "Partly Cloudy"; 3 -> "Cloudy"; 45, 48 -> "Fog"; in 51..67 -> "Rain"; in 71..77 -> "Snow"; in 80..82 -> "Showers"; in 95..99 -> "Thunderstorm"; else -> "Fair" }

suspend fun fetchWeather() {
  withContext(Dispatchers.IO) {
    try {
        val u = "https://api.open-meteo.com/v1/forecast?latitude=${Store.lat}&longitude=${Store.lon}&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,weather_code&timezone=auto&forecast_days=4"
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 6000
        val j = JSONObject(c.inputStream.bufferedReader().readText())
        val cur = j.getJSONObject("current"); val d = j.getJSONObject("daily")
        val hi = d.getJSONArray("temperature_2m_max"); val lo = d.getJSONArray("temperature_2m_min")
        val cd = d.getJSONArray("weather_code"); val dt = d.getJSONArray("time")
        val days = (0 until hi.length()).map {
            val dd = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dt.getString(it))!!
            Day(SimpleDateFormat("EEE", Locale.US).format(dd), hi.getDouble(it).roundToInt(), lo.getDouble(it).roundToInt(), cd.getInt(it))
        }
        Store.weather = Weather(cur.getDouble("temperature_2m").roundToInt(), cur.getInt("weather_code"), days)
    } catch (_: Exception) {}
    Unit
  }
}

// ---------------- Calculator engine ----------------
class Ev(val s: String) {
    var i = 0
    fun p(): Double { var v = t(); while (i < s.length && (s[i] == '+' || s[i] == '-')) { val o = s[i++]; val r = t(); v = if (o == '+') v + r else v - r }; return v }
    fun t(): Double { var v = f(); while (i < s.length && (s[i] == '*' || s[i] == '/')) { val o = s[i++]; val r = f(); v = if (o == '*') v * r else v / r }; return v }
    fun f(): Double {
        if (i < s.length && s[i] == '-') { i++; return -f() }
        if (i < s.length && s[i] == '(') { i++; val v = p(); i++; return v }
        val st = i
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        return s.substring(st, i).toDouble()
    }
}

fun calc(s: String): String? = try {
    val q = s.replace('×', '*').replace('÷', '/').replace('−', '-').replace("%", "/100")
    val e = Ev(q); val v = e.p()
    if (e.i < q.length || v.isNaN() || v.isInfinite()) null
    else BigDecimal(v).setScale(8, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
} catch (_: Exception) { null }

fun aiReply(t0: String): String {
    val t = t0.lowercase(Locale.getDefault()); val w = Store.weather
    return when {
        Regex("plan|schedule|study").containsMatchIn(t) -> "Study plan: 7–9 Maths, 10–12 Physics, 4–5 Revision, 8 PM Chemistry practice."
        Regex("time|samay").containsMatchIn(t) -> "Abhi samay " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        Regex("weather|mausam").containsMatchIn(t) -> if (w != null) "$CITY: ${w.temp}°C, ${wxText(w.code)}" else "Weather abhi load nahi hua, internet check karo."
        Regex("write|message").containsMatchIn(t) -> "Draft: \"Hi! Kal milte hain, time confirm kar dena. Thanks!\""
        Regex("summar").containsMatchIn(t) -> "Text paste karo, main 3 points me bata dunga."
        Regex("image").containsMatchIn(t) -> "Image feature abhi demo hai."
        Regex("hello|namaste|^hi").containsMatchIn(t) -> "Namaste!"
        else -> "Samajh gaya: \"${t0.take(40)}\". (Local demo AI, rule-based)"
    }
}
