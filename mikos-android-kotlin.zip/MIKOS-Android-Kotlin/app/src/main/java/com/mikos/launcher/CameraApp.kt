package com.mikos.launcher

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

suspend fun <T> ListenableFuture<T>.awaitF(ctx: Context): T = suspendCancellableCoroutine { c ->
    addListener({ try { c.resume(get()) } catch (e: Exception) { c.resumeWithException(e) } }, ContextCompat.getMainExecutor(ctx))
}

@Composable fun CameraApp(close: () -> Unit) {
    val perms = if (Build.VERSION.SDK_INT <= 28) listOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE) else listOf(Manifest.permission.CAMERA)
    NeedPerm(perms, "Camera chalane aur photo save karne ke liye permission chahiye") { CameraBody(close) }
}

@Composable fun CameraBody(close: () -> Unit) {
    val ctx = LocalContext.current; val lo = LocalLifecycleOwner.current; val scope = rememberCoroutineScope()
    val sp = remember { ctx.getSharedPreferences("mikos_ai", Context.MODE_PRIVATE) }
    var pv by remember { mutableStateOf<PreviewView?>(null) }
    var cam by remember { mutableStateOf<Camera?>(null) }
    var cap by remember { mutableStateOf<ImageCapture?>(null) }
    var mode by remember { mutableStateOf("Auto") }; var front by remember { mutableStateOf(false) }
    var flash by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var zoom by remember { mutableFloatStateOf(1f) }; var minZ by remember { mutableFloatStateOf(1f) }; var maxZ by remember { mutableFloatStateOf(1f) }
    var ev by remember { mutableIntStateOf(0) }; var evMin by remember { mutableIntStateOf(0) }; var evMax by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }; var thumb by remember { mutableStateOf<Bitmap?>(null) }; var lastUri by remember { mutableStateOf<Uri?>(null) }
    var note by remember { mutableStateOf<String?>(null) }; var suggest by remember { mutableStateOf<String?>(null) }
    var aiText by remember { mutableStateOf<String?>(null) }; var aiBusy by remember { mutableStateOf(false) }
    var focus by remember { mutableStateOf<Offset?>(null) }; var shutter by remember { mutableStateOf(false) }
    val dens = LocalDensity.current.density
    val modes = listOf("Auto", "HDR", "Night", "Portrait", "Moon")

    LaunchedEffect(pv, mode, front) {
        val view = pv ?: return@LaunchedEffect
        try {
            val provider = ProcessCameraProvider.getInstance(ctx).awaitF(ctx)
            val base = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            var sel = base
            val em = when (mode) { "HDR" -> ExtensionMode.HDR; "Night" -> ExtensionMode.NIGHT; "Portrait" -> ExtensionMode.BOKEH; else -> null }
            if (em != null) {
                try {
                    val ext = ExtensionsManager.getInstanceAsync(ctx, provider).awaitF(ctx)
                    if (ext.isExtensionAvailable(base, em)) { sel = ext.getExtensionEnabledCameraSelector(base, em); note = "$mode: phone ka hardware AI mode on" }
                    else note = "$mode hardware mode is phone me nahi hai, MIKOS software AI use hoga"
                } catch (e: Exception) { note = "$mode: software AI use hoga" }
            } else note = null
            val prev = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
            val ic = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).setJpegQuality(100).setFlashMode(flash).build()
            provider.unbindAll()
            val c = try { provider.bindToLifecycle(lo, sel, prev, ic) } catch (e: Exception) { provider.unbindAll(); provider.bindToLifecycle(lo, base, prev, ic) }
            cam = c; cap = ic
            val zs = c.cameraInfo.zoomState.value
            minZ = zs?.minZoomRatio ?: 1f; maxZ = zs?.maxZoomRatio ?: 1f
            zoom = if (mode == "Moon") minOf(maxZ, 8f).coerceAtLeast(minZ) else minZ
            c.cameraControl.setZoomRatio(zoom)
            val r = c.cameraInfo.exposureState.exposureCompensationRange
            evMin = r.lower; evMax = r.upper
            ev = if (mode == "Moon") r.lower else 0
            c.cameraControl.setExposureCompensationIndex(ev)
            if (mode == "Moon") note = "Moon mode: zoom ${"%.1f".format(zoom)}x, exposure kam. Phone sthir rakho"
        } catch (e: Exception) { note = "Camera start nahi hua: ${e.message}" }
    }
    LaunchedEffect(flash, cap) { cap?.flashMode = flash }
    LaunchedEffect(pv, mode) {
        while (true) {
            delay(1200)
            val b = pv?.bitmap
            if (b != null) { val r = Proc.scene(b); suggest = if (r == 2 && mode != "Moon") "Moon" else if (r == 1 && mode == "Auto") "Night" else null }
        }
    }
    LaunchedEffect(focus) { if (focus != null) { delay(900); focus = null } }
    LaunchedEffect(shutter) { if (shutter) { delay(110); shutter = false } }
    LaunchedEffect(note) { if (note != null) { delay(4000); note = null } }

    fun shoot() {
        val c = cap ?: return; if (busy) return
        busy = true; shutter = true
        c.takePicture(ContextCompat.getMainExecutor(ctx), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val rot = image.imageInfo.rotationDegrees
                val bmp = try { image.toBitmap() } catch (e: Exception) { null }
                image.close()
                if (bmp == null) { busy = false; return }
                val m = mode; val fr = front
                scope.launch(Dispatchers.Default) {
                    try {
                        val (out, tag) = Proc.enhance(Proc.rotate(bmp, rot, fr), m)
                        val uri = Proc.save(ctx, out, tag)
                        val th = Proc.limit(out, 200)
                        withContext(Dispatchers.Main) { thumb = th; lastUri = uri; Toast.makeText(ctx, "Photo save ho gayi: Pictures/MIKOS", Toast.LENGTH_SHORT).show() }
                    } catch (e: Throwable) { withContext(Dispatchers.Main) { Toast.makeText(ctx, "Photo process nahi hui (memory kam?)", Toast.LENGTH_SHORT).show() } }
                    busy = false
                }
            }
            override fun onError(e: ImageCaptureException) { busy = false; Toast.makeText(ctx, "Capture error", Toast.LENGTH_SHORT).show() }
        })
    }
    fun aiScene() {
        val key = sp.getString("key", "") ?: ""
        if (key.isBlank()) { Toast.makeText(ctx, "Pehle MIKOS AI me access key daalo", Toast.LENGTH_SHORT).show(); return }
        val b = pv?.bitmap ?: return
        aiBusy = true
        scope.launch(Dispatchers.IO) {
            val r = visionAsk(key, b, SCENE_PROMPT)
            withContext(Dispatchers.Main) {
                aiText = r; aiBusy = false
                val u = r.uppercase()
                if (u.startsWith("MOON")) mode = "Moon" else if (u.startsWith("NIGHT")) mode = "Night" else if (u.startsWith("PORTRAIT")) mode = "Portrait"
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { c -> PreviewView(c).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE; scaleType = PreviewView.ScaleType.FILL_CENTER; pv = this } }, modifier = Modifier.fillMaxSize())
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) { detectTransformGestures { _, _, z, _ -> val nz = (zoom * z).coerceIn(minZ, maxZ); if (nz != zoom) { zoom = nz; cam?.cameraControl?.setZoomRatio(nz) } } }
                .pointerInput(Unit) { detectTapGestures { o -> focus = o; val f = pv?.meteringPointFactory; if (f != null) cam?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(f.createPoint(o.x, o.y)).build()) } }
        )
        focus?.let { f -> Box(Modifier.offset { IntOffset((f.x - 35 * dens).toInt(), (f.y - 35 * dens).toInt()) }.size(70.dp).border(2.dp, Color(0xFFFFD54F), RoundedCornerShape(10.dp))) }
        if (shutter) Box(Modifier.fillMaxSize().background(Color.White))

        Row(Modifier.fillMaxWidth().topSafe().padding(top = 44.dp, start = 10.dp, end = 10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IcBtn(Icons.Filled.ArrowBackIosNew) { close() }
            Text("${"%.1f".format(zoom)}x · $mode", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Row {
                IcBtn(when (flash) { ImageCapture.FLASH_MODE_ON -> Icons.Filled.FlashOn; ImageCapture.FLASH_MODE_AUTO -> Icons.Filled.FlashAuto; else -> Icons.Filled.FlashOff }) {
                    flash = when (flash) { ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO; ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON; else -> ImageCapture.FLASH_MODE_OFF }
                }
                if (aiBusy) Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(22.dp), color = Color(0xFF4DC3FF), strokeWidth = 2.dp) }
                else IcBtn(Icons.Filled.AutoAwesome) { aiScene() }
            }
        }
        Column(Modifier.align(Alignment.TopCenter).topSafe().padding(top = 96.dp, start = 16.dp, end = 16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            note?.let { Text(it, color = Color.White, fontSize = 12.sp, modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x99000000)).padding(horizontal = 12.dp, vertical = 6.dp)) }
            suggest?.let { s -> Text("$s scene dikha. $s mode lagao? (tap)", color = Color.White, fontSize = 12.sp, modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xCC3B6BFF)).clickable { mode = s; suggest = null }.padding(horizontal = 12.dp, vertical = 6.dp)) }
        }
        aiText?.let { t ->
            Column(Modifier.align(Alignment.Center).padding(24.dp).glass(22.dp).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Ic(Icons.Filled.AutoAwesome, Color(0xFF4DC3FF)); Spacer(Modifier.width(8.dp)); Text("MIKOS AI scene", color = Color.White, fontWeight = FontWeight.Bold) }
                Text(t, color = Color.White, fontSize = 14.sp)
                Text("Band karo", color = Color(0xFF4DC3FF), modifier = Modifier.clickable { aiText = null }.padding(4.dp))
            }
        }
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(bottom = 14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1f, 2f, 5f, 10f).filter { it >= minZ && it <= maxZ }.forEach { z ->
                    Text("${z.toInt()}x", color = if (kotlin.math.abs(zoom - z) < 0.3f) Color(0xFFFFD54F) else Color.White, fontSize = 13.sp, modifier = Modifier.clip(CircleShape).background(Color(0x66000000)).clickable { zoom = z; cam?.cameraControl?.setZoomRatio(z) }.padding(horizontal = 12.dp, vertical = 6.dp))
                }
            }
            if (evMax > evMin) Row(Modifier.padding(horizontal = 40.dp), verticalAlignment = Alignment.CenterVertically) {
                Ic(Icons.Filled.LightMode, size = 18.dp)
                Slider(ev.toFloat(), { ev = it.toInt(); cam?.cameraControl?.setExposureCompensationIndex(ev) }, valueRange = evMin.toFloat()..evMax.toFloat())
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                modes.forEach { m -> Text(m, color = if (mode == m) Color(0xFFFFD54F) else Color.White, fontWeight = if (mode == m) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.clickable { mode = m }.padding(6.dp)) }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x44FFFFFF)).clickable { lastUri?.let { u -> ctx.go(Intent(Intent.ACTION_VIEW).setDataAndType(u, "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } }, contentAlignment = Alignment.Center) {
                    thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                }
                Box(Modifier.size(78.dp).border(4.dp, Color.White, CircleShape).padding(7.dp).clip(CircleShape).background(if (busy) Color(0xFF4DC3FF) else Color.White).clickable { shoot() }, contentAlignment = Alignment.Center) {
                    if (busy) CircularProgressIndicator(Modifier.size(30.dp), color = Color.White, strokeWidth = 3.dp)
                }
                Box(Modifier.size(54.dp).clip(CircleShape).background(Color(0x44FFFFFF)).clickable { front = !front }, contentAlignment = Alignment.Center) { Ic(Icons.Filled.FlipCameraAndroid, size = 28.dp) }
            }
        }
    }
}
