package com.mikos.launcher

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

// Real on-device photo pipeline: levels + denoise + sharpen, Moon crop. No fake textures are pasted.
object Proc {
    fun limit(b: Bitmap, maxPx: Int): Bitmap {
        val m = max(b.width, b.height); if (m <= maxPx) return b
        val s = maxPx.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * s).toInt().coerceAtLeast(1), (b.height * s).toInt().coerceAtLeast(1), true)
    }

    fun rotate(b: Bitmap, deg: Int, mirror: Boolean): Bitmap {
        if (deg == 0 && !mirror) return b
        val m = Matrix(); m.postRotate(deg.toFloat()); if (mirror) m.postScale(-1f, 1f)
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    fun levels(b: Bitmap, lift: Float, gamma: Float, clip: Float): Bitmap {
        val w = b.width; val h = b.height; val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val hist = IntArray(256)
        for (p in px) { hist[(p shr 16) and 255]++; hist[(p shr 8) and 255]++; hist[p and 255]++ }
        val t = (px.size * 3 * clip).toInt()
        var lo = 0; var acc = 0
        while (lo < 254) { acc += hist[lo]; if (acc > t) break; lo++ }
        var hi = 255; acc = 0
        while (hi > lo + 1) { acc += hist[hi]; if (acc > t) break; hi-- }
        val lut = IntArray(256) { i ->
            var v = ((i - lo).toFloat() / (hi - lo)).coerceIn(0f, 1f)
            v = v.pow(gamma)
            v = (v + lift * 2f * v * (1f - v)).coerceIn(0f, 1f)
            (v * 255f + .5f).toInt()
        }
        for (i in px.indices) {
            val p = px[i]
            px[i] = (p and 0xFF000000.toInt()) or (lut[(p shr 16) and 255] shl 16) or (lut[(p shr 8) and 255] shl 8) or lut[p and 255]
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    fun sharpen(b: Bitmap, amount: Float): Bitmap {
        val w = b.width; val h = b.height; val src = IntArray(w * h); b.getPixels(src, 0, w, 0, 0, w, h)
        val out = src.copyOf(); val a = (amount * 256).toInt()
        for (y in 1 until h - 1) {
            var i = y * w + 1
            for (x in 1 until w - 1) {
                val c = src[i]; val l = src[i - 1]; val r = src[i + 1]; val u = src[i - w]; val d = src[i + w]
                var res = c and 0xFF000000.toInt()
                for (k in 0..2) {
                    val s = 16 - 8 * k
                    val cc = (c shr s) and 255
                    val avg = (((l shr s) and 255) + ((r shr s) and 255) + ((u shr s) and 255) + ((d shr s) and 255)) shr 2
                    val v = (cc + (((cc - avg) * a) shr 8)).coerceIn(0, 255)
                    res = res or (v shl s)
                }
                out[i] = res; i++
            }
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    fun denoise(b: Bitmap): Bitmap {
        val w = b.width; val h = b.height; val src = IntArray(w * h); b.getPixels(src, 0, w, 0, 0, w, h)
        val out = src.copyOf()
        for (y in 1 until h - 1) {
            var i = y * w + 1
            for (x in 1 until w - 1) {
                val c = src[i]
                val lum = (((c shr 16) and 255) + ((c shr 8) and 255) + (c and 255)) / 3
                if (lum < 70) {
                    val l = src[i - 1]; val r = src[i + 1]; val u = src[i - w]; val d = src[i + w]
                    var res = c and 0xFF000000.toInt()
                    for (k in 0..2) {
                        val s = 16 - 8 * k
                        val avg = (((c shr s) and 255) + ((l shr s) and 255) + ((r shr s) and 255) + ((u shr s) and 255) + ((d shr s) and 255)) / 5
                        val v = (((c shr s) and 255) * 2 + avg * 3) / 5
                        res = res or (v shl s)
                    }
                    out[i] = res
                }
                i++
            }
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun lum(p: Int) = ((((p shr 16) and 255) * 3) + (((p shr 8) and 255) * 6) + (p and 255)) / 10

    // Finds the bright disc (moon), crops around it and upscales. Returns null if no moon-like blob.
    fun moonCrop(b: Bitmap): Bitmap? {
        val s = Bitmap.createScaledBitmap(b, 256, (256f * b.height / b.width).toInt().coerceAtLeast(1), true)
        var n = 0; var sx = 0L; var sy = 0L
        for (y in 0 until s.height) for (x in 0 until s.width) if (lum(s.getPixel(x, y)) > 215) { n++; sx += x; sy += y }
        if (n < 8 || n > s.width * s.height * 0.3) return null
        val k = b.width.toFloat() / s.width
        val cx = sx / n.toFloat() * k; val cy = sy / n.toFloat() * k
        val r = sqrt(n / PI.toFloat()) * k
        val sideF = max(r * 5f, min(b.width, b.height) * 0.30f)
        val side = min(sideF.toInt(), min(b.width, b.height))
        val x0 = (cx - side / 2f).toInt().coerceIn(0, b.width - side)
        val y0 = (cy - side / 2f).toInt().coerceIn(0, b.height - side)
        val crop = Bitmap.createBitmap(b, x0, y0, side, side)
        return if (side < 2048) Bitmap.createScaledBitmap(crop, 2048, 2048, true) else crop
    }

    // 0 = normal, 1 = night scene, 2 = moon-like scene
    fun scene(b: Bitmap): Int {
        val s = Bitmap.createScaledBitmap(b, 64, (64f * b.height / b.width).toInt().coerceAtLeast(1), true)
        var sum = 0L; var br = 0; val n = s.width * s.height
        for (y in 0 until s.height) for (x in 0 until s.width) { val l = lum(s.getPixel(x, y)); sum += l; if (l > 215) br++ }
        val mean = sum / n; val f = br.toFloat() / n
        return if (mean < 70 && f in 0.002f..0.15f) 2 else if (mean < 55) 1 else 0
    }

    fun enhance(src: Bitmap, mode: String): Pair<Bitmap, String> {
        var b = limit(src, 3600); var tag = mode.lowercase(Locale.US)
        when (mode) {
            "Moon" -> { val c = moonCrop(b); if (c != null) b = c else tag = "moonframe"; b = levels(b, 0f, 1.05f, 0.002f); b = sharpen(b, 1.0f); b = sharpen(b, 0.6f) }
            "Night" -> { b = denoise(b); b = levels(b, 0.35f, 0.85f, 0.004f); b = sharpen(b, 0.35f) }
            "HDR" -> { b = levels(b, 0.3f, 0.92f, 0.004f); b = sharpen(b, 0.45f) }
            else -> { b = levels(b, 0.08f, 1f, 0.004f); b = sharpen(b, 0.4f) }
        }
        return b to tag
    }

    fun save(ctx: Context, b: Bitmap, tag: String): Uri? {
        val name = "MIKOS_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "_" + tag + ".jpg"
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) { put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MIKOS"); put(MediaStore.Images.Media.IS_PENDING, 1) }
        }
        val r = ctx.contentResolver
        val uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        r.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        if (Build.VERSION.SDK_INT >= 29) { v.clear(); v.put(MediaStore.Images.Media.IS_PENDING, 0); r.update(uri, v, null, null) }
        return uri
    }
}

const val SCENE_PROMPT = "Look at this camera frame. Reply in Hinglish, max 3 short lines. Line 1 must start with exactly one word: MOON, NIGHT, PORTRAIT, FOOD, LANDSCAPE, DOCUMENT or OTHER. Then give 1-2 quick tips (zoom, exposure, steady hands) to get the best photo."

// AI vision via MIKOS server: scene recognition + shooting tips (uses the access key saved in MIKOS AI settings)
fun visionAsk(key: String, bmp: Bitmap, prompt: String): String {
    return try {
        val s = Proc.limit(bmp, 1024); val bo = ByteArrayOutputStream(); s.compress(Bitmap.CompressFormat.JPEG, 80, bo)
        val b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
        val img = JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
        val content = JSONArray().put(img).put(JSONObject().put("type", "text").put("text", prompt))
        val body = JSONObject().put("stream", false).put("max_tokens", 400).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val c = URL("$MIKOS_SERVER/api/chat").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("content-type", "application/json"); c.setRequestProperty("x-mikos-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode != 200) {
            val e = c.errorStream?.bufferedReader()?.readText() ?: ""
            return try { JSONObject(e).getString("error") } catch (x: Exception) { "AI error ${c.responseCode}" }
        }
        JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    } catch (e: Exception) { "AI error: ${e.message ?: "network"}" }
}
