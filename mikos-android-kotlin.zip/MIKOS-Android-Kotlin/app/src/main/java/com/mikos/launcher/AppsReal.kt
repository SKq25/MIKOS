package com.mikos.launcher

import android.Manifest
import android.app.NotificationManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SmsManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable fun NeedPerm(perms: List<String>, why: String, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    resumeTick()
    fun granted() = perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }
    var ok by remember { mutableStateOf(granted()) }
    val l = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ok = granted() }
    if (ok) content() else Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(why, color = Color.White, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
        Button(onClick = { l.launch(perms.toTypedArray()) }) { Text("Permission do") }
    }
}

fun Context.call(n: String) { go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n)))) }
fun fmt(ms: Long): String = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(ms))

// ---------------- Phone ----------------
data class Contact(val name: String, val num: String)
data class CallRow(val name: String, val num: String, val type: Int, val date: Long)

fun loadContacts(c: Context): List<Contact> = try {
    val out = ArrayList<Contact>()
    val u = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
    c.contentResolver.query(u, arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")?.use { cu ->
        while (cu.moveToNext()) out.add(Contact(cu.getString(0) ?: "", cu.getString(1) ?: ""))
    }
    out.distinctBy { it.name + it.num }
} catch (e: Exception) { emptyList() }

fun loadCalls(c: Context): List<CallRow> = try {
    val out = ArrayList<CallRow>()
    c.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE), null, null, CallLog.Calls.DATE + " DESC")?.use { cu ->
        var n = 0
        while (cu.moveToNext() && n < 60) { out.add(CallRow(cu.getString(1) ?: "", cu.getString(0) ?: "", cu.getInt(2), cu.getLong(3))); n++ }
    }
    out
} catch (e: Exception) { emptyList() }

@Composable fun PhoneApp() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    NeedPerm(listOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG), "Calling, contacts aur recents ke liye permission chahiye") {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf("Keypad", "Contacts", "Recents").forEachIndexed { i, t ->
                    Text(t, color = if (tab == i) Color(0xFF4DC3FF) else Color.White, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.clickable { tab = i }.padding(10.dp))
                }
            }
            when (tab) {
                0 -> {
                    var n by remember { mutableStateOf("") }
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(n.ifEmpty { " " }, color = Color.White, fontSize = 34.sp, modifier = Modifier.height(60.dp))
                        "123456789*0#".chunked(3).forEach { row ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                                row.forEach { k -> Box(Modifier.size(66.dp).clip(CircleShape).background(Color(0xFF151C58)).clickable { n += k }, contentAlignment = Alignment.Center) { Text(k.toString(), color = Color.White, fontSize = 26.sp) } }
                            }
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                            Spacer(Modifier.size(66.dp))
                            Box(Modifier.size(70.dp).clip(CircleShape).background(Color(0xFF34C759)).clickable { if (n.isNotEmpty()) ctx.call(n) }, contentAlignment = Alignment.Center) { Ic(Icons.Filled.Call, size = 30.dp) }
                            Box(Modifier.size(66.dp).clip(CircleShape).clickable { n = n.dropLast(1) }, contentAlignment = Alignment.Center) { Ic(Icons.Filled.Backspace, size = 26.dp) }
                        }
                    }
                }
                1 -> {
                    val all by produceState(emptyList<Contact>()) { value = withContext(Dispatchers.IO) { loadContacts(ctx) } }
                    var q by remember { mutableStateOf("") }
                    Column(Modifier.fillMaxSize()) {
                        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Contact search") }, shape = RoundedCornerShape(26.dp))
                        LazyColumn { items(all.filter { it.name.contains(q, true) || it.num.contains(q) }) { c ->
                            Row(Modifier.fillMaxWidth().clickable { ctx.call(c.num) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF3B6BFF)), contentAlignment = Alignment.Center) { Text(c.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold) }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) { Text(c.name, color = Color.White); Text(c.num, color = Color(0xAAFFFFFF), fontSize = 12.sp) }
                                Ic(Icons.Filled.Call, Color(0xFF34C759))
                            }
                        } }
                    }
                }
                else -> {
                    val calls by produceState(emptyList<CallRow>()) { value = withContext(Dispatchers.IO) { loadCalls(ctx) } }
                    LazyColumn { items(calls) { c ->
                        Row(Modifier.fillMaxWidth().clickable { ctx.call(c.num) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Ic(when (c.type) { CallLog.Calls.OUTGOING_TYPE -> Icons.Filled.CallMade; CallLog.Calls.MISSED_TYPE -> Icons.Filled.CallMissed; else -> Icons.Filled.CallReceived }, if (c.type == CallLog.Calls.MISSED_TYPE) Color(0xFFFF5252) else Color(0xFF4DC3FF))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) { Text(c.name.ifEmpty { c.num }, color = Color.White); Text(fmt(c.date), color = Color(0xAAFFFFFF), fontSize = 12.sp) }
                        }
                    } }
                }
            }
        }
    }
}

// ---------------- Messages ----------------
data class Sms(val addr: String, val body: String, val type: Int, val date: Long)

fun loadSms(c: Context): List<Sms> = try {
    val out = ArrayList<Sms>()
    c.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.TYPE, Telephony.Sms.DATE), null, null, Telephony.Sms.DATE + " DESC")?.use { cu ->
        var n = 0
        while (cu.moveToNext() && n < 600) { out.add(Sms(cu.getString(0) ?: "", cu.getString(1) ?: "", cu.getInt(2), cu.getLong(3))); n++ }
    }
    out
} catch (e: Exception) { emptyList() }

@Suppress("DEPRECATION")
fun sendSms(c: Context, to: String, t: String) {
    try {
        val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        sm.sendTextMessage(to, null, t, null, null)
    } catch (e: Exception) { Toast.makeText(c, "SMS nahi gaya", Toast.LENGTH_SHORT).show() }
}

@Composable fun MessagesApp() {
    val ctx = LocalContext.current
    NeedPerm(listOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS), "SMS padhne aur bhejne ke liye permission chahiye") {
        val loaded by produceState(emptyList<Sms>()) { value = withContext(Dispatchers.IO) { loadSms(ctx) } }
        val sent = remember { mutableStateListOf<Sms>() }
        val all = sent.toList() + loaded
        var sel by remember { mutableStateOf<String?>(null) }
        var newNum by remember { mutableStateOf("") }
        BackHandler(sel != null) { sel = null }
        if (sel == null) {
            Column(Modifier.fillMaxSize()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(newNum, { newNum = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Naya number") }, shape = RoundedCornerShape(26.dp))
                    Spacer(Modifier.width(8.dp)); Button(onClick = { if (newNum.isNotBlank()) sel = newNum }) { Ic(Icons.Filled.Add, size = 20.dp) }
                }
                val threads = all.groupBy { it.addr }.map { it.value.first() }.sortedByDescending { it.date }
                LazyColumn { items(threads) { t ->
                    Row(Modifier.fillMaxWidth().clickable { sel = t.addr }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF3B6BFF)), contentAlignment = Alignment.Center) { Ic(Icons.Filled.Person, size = 22.dp) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text(t.addr, color = Color.White, fontWeight = FontWeight.SemiBold); Text(t.body, color = Color(0xAAFFFFFF), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        Text(fmt(t.date), color = Color(0x88FFFFFF), fontSize = 10.sp)
                    }
                } }
            }
        } else {
            val a = sel!!
            val conv = all.filter { it.addr == a }.reversed()
            var txt by remember { mutableStateOf("") }
            Column(Modifier.fillMaxSize()) {
                Text(a, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) { items(conv) { m ->
                    val me = m.type == 2
                    Box(Modifier.fillMaxWidth(), contentAlignment = if (me) Alignment.CenterEnd else Alignment.CenterStart) {
                        Text(m.body, color = Color.White, modifier = Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(18.dp)).background(if (me) Color(0xFF3B6BFF) else Color(0xFF1C2670)).padding(10.dp))
                    }
                } }
                Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(txt, { txt = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Message") }, shape = RoundedCornerShape(26.dp))
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { if (txt.isNotBlank()) { sendSms(ctx, a, txt); sent.add(0, Sms(a, txt, 2, System.currentTimeMillis())); txt = "" } }) { Ic(Icons.Filled.Send, size = 20.dp) }
                }
            }
        }
    }
}

// ---------------- Gallery ----------------
fun loadImages(c: Context): List<Uri> = try {
    val out = ArrayList<Uri>()
    val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    c.contentResolver.query(base, arrayOf(MediaStore.Images.Media._ID), null, null, MediaStore.Images.Media.DATE_ADDED + " DESC")?.use { cu ->
        var n = 0
        while (cu.moveToNext() && n < 400) { out.add(ContentUris.withAppendedId(base, cu.getLong(0))); n++ }
    }
    out
} catch (e: Exception) { emptyList() }

@Composable fun GalleryApp() {
    val ctx = LocalContext.current
    val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    NeedPerm(listOf(p), "Photos dikhane ke liye permission chahiye") {
        val imgs by produceState(emptyList<Uri>()) { value = withContext(Dispatchers.IO) { loadImages(ctx) } }
        var sel by remember { mutableStateOf<Uri?>(null) }
        BackHandler(sel != null) { sel = null }
        if (imgs.isEmpty()) Text("Koi photo nahi mili", color = Color(0x99FFFFFF))
        LazyVerticalGrid(GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            items(imgs) { u -> AsyncImage(u, null, Modifier.aspectRatio(1f).clickable { sel = u }, contentScale = ContentScale.Crop) }
        }
        sel?.let { u -> Box(Modifier.fillMaxSize().background(Color.Black).clickable { sel = null }) { AsyncImage(u, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) } }
    }
}

// ---------------- Clock ----------------
@Composable fun ClockApp() {
    val ctx = LocalContext.current
    var ms by remember { mutableLongStateOf(0L) }; var run by remember { mutableStateOf(false) }
    LaunchedEffect(run) { if (run) { val st = System.currentTimeMillis() - ms; while (run) { ms = System.currentTimeMillis() - st; delay(30) } } }
    val cs = ms / 10
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("%02d:%02d.%02d".format(cs / 6000, (cs / 100) % 60, cs % 100), color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Light)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { run = !run }) { Text(if (run) "Stop" else "Start") }
            Button(onClick = { run = false; ms = 0 }) { Text("Reset") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { ctx.go(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }) { Ic(Icons.Filled.Alarm, size = 18.dp); Spacer(Modifier.width(6.dp)); Text("Alarms") }
            Button(onClick = { ctx.go(Intent(AlarmClock.ACTION_SET_TIMER)) }) { Ic(Icons.Filled.Timer, size = 18.dp); Spacer(Modifier.width(6.dp)); Text("Timer") }
        }
    }
}

// ---------------- Settings ----------------
@Composable fun SRow(icon: ImageVector, title: String, sub: String = "", f: () -> Unit) {
    Row(Modifier.fillMaxWidth().glass(18.dp).clickable { f() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Ic(icon, Color(0xFF4DC3FF)); Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) { Text(title, color = Color.White); if (sub.isNotEmpty()) Text(sub, color = Color(0xAAFFFFFF), fontSize = 12.sp) }
    }
}

@Composable fun SettingsApp() {
    val ctx = LocalContext.current; val net = netInfo(); val bat = battery(); val rs = radioState()
    resumeTick()
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val dnd = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
    val air = try { Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (e: Exception) { false }
    fun s(a: String) = ctx.go(Intent(a))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SRow(Icons.Filled.SignalCellularAlt, "Network", net.second + if (air) " (Airplane mode)" else "") { s(Settings.ACTION_WIRELESS_SETTINGS) }
        SRow(Icons.Filled.Wifi, "Wi-Fi", (if (rs.first) "On" else "Off") + " · dabao to toggle") { toggleWifi(ctx) }
        SRow(Icons.Filled.Bluetooth, "Bluetooth", (if (rs.second) "On" else "Off") + " · dabao to toggle") { toggleBt(ctx) }
        SRow(Icons.Filled.BatteryFull, "Battery", "$bat%" + if (Stat.charging) " · charging" else "") { s(Settings.ACTION_BATTERY_SAVER_SETTINGS) }
        SRow(Icons.Filled.LightMode, "Display") { s(Settings.ACTION_DISPLAY_SETTINGS) }
        SRow(Icons.Filled.VolumeUp, "Sound") { s(Settings.ACTION_SOUND_SETTINGS) }
        SRow(Icons.Filled.DarkMode, "Do Not Disturb", if (dnd) "On" else "Off") { s(Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS) }
        SRow(Icons.Filled.Notifications, "Notification access", if (notifAccess(ctx)) "Allowed" else "Not allowed (dabao aur allow karo)") { s(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
        SRow(Icons.Filled.Home, "Default home app", "MIKOS ko default banao") { s(Settings.ACTION_HOME_SETTINGS) }
        SRow(Icons.Filled.Security, "MIKOS permissions") { ctx.go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))) }
        SRow(Icons.Filled.Apps, "Apps") { s(Settings.ACTION_APPLICATION_SETTINGS) }
        SRow(Icons.Filled.Storage, "Storage") { s(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }
        SRow(Icons.Filled.Lock, "Security") { s(Settings.ACTION_SECURITY_SETTINGS) }
        SRow(Icons.Filled.Info, "About phone", Build.MODEL) { s(Settings.ACTION_DEVICE_INFO_SETTINGS) }
        SRow(Icons.Filled.Settings, "Poori system Settings") { s(Settings.ACTION_SETTINGS) }
    }
}
