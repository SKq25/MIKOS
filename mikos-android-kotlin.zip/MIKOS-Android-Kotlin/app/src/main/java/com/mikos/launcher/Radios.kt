package com.mikos.launcher

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay

object Radios {
    fun wifiOn(c: Context): Boolean = try {
        (c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) { false }

    @Suppress("DEPRECATION")
    fun setWifi(c: Context, on: Boolean): Boolean = try {
        (c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).setWifiEnabled(on)
    } catch (e: Exception) { false }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun btOn(c: Context): Boolean = try { BluetoothAdapter.getDefaultAdapter()?.isEnabled == true } catch (e: Exception) { false }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun setBt(c: Context, on: Boolean): Boolean {
        return try {
            val a = BluetoothAdapter.getDefaultAdapter() ?: return false
            if (on) a.enable() else a.disable()
        } catch (e: Exception) { false }
    }
}

@Composable fun radioState(): Pair<Boolean, Boolean> {
    val c = LocalContext.current
    var r by remember { mutableStateOf(false to false) }
    LaunchedEffect(Unit) { while (true) { r = Radios.wifiOn(c) to Radios.btOn(c); delay(1000) } }
    return r
}

fun toggleWifi(c: Context) {
    val target = !Radios.wifiOn(c)
    if (!Radios.setWifi(c, target)) {
        Toast.makeText(c, "Is phone par Wi-Fi direct toggle blocked hai, system panel khol raha hu", Toast.LENGTH_SHORT).show()
        c.go(Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS))
    }
}

fun toggleBt(c: Context) {
    val target = !Radios.btOn(c)
    if (!Radios.setBt(c, target)) {
        Toast.makeText(c, "Is phone par Bluetooth direct toggle blocked hai, settings khol raha hu", Toast.LENGTH_SHORT).show()
        c.go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    }
}
