package com.mikos.launcher

import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { MikosRoot(this) } }
        hideBars()
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideBars() }
    private fun hideBars() {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.statusBars())
    }
}

fun tryUnlock(act: FragmentActivity, ok: () -> Unit) {
    val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
    if (BiometricManager.from(act).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) { ok(); return }
    val p = BiometricPrompt(act, ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { ok() }
    })
    p.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("MIKOS unlock").setSubtitle("Fingerprint / PIN / pattern").setAllowedAuthenticators(auth).build())
}

@Composable fun MikosRoot(act: FragmentActivity) {
    val ctx = LocalContext.current
    val hap = LocalHapticFeedback.current
    val apps = remember { loadApps(ctx) }
    var drawer by remember { mutableStateOf(false) }
    var cc by remember { mutableStateOf(false) }
    var locked by remember { mutableStateOf(true) }
    var app by remember { mutableStateOf<String?>(null) }
    var last by remember { mutableStateOf("AI") }
    if (app != null) last = app!!
    LaunchedEffect(Unit) { loadCity(ctx); fetchWeather() }
    fun unlock() { tryUnlock(act) { locked = false; hap.performHapticFeedback(HapticFeedbackType.LongPress) } }
    BackHandler(app != null || drawer || cc) { if (app != null) app = null else { drawer = false; cc = false } }
    CompositionLocalProvider(LocalApps provides apps) {
        Box(
            Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {
                var t = 0f
                detectVerticalDragGestures(
                    onDragStart = { t = 0f },
                    onDragEnd = {
                        if (app == null) {
                            if (locked) { if (t < -140) unlock() }
                            else if (drawer) { if (t > 160) drawer = false }
                            else if (cc) { if (t < -160) cc = false }
                            else { if (t < -160) drawer = true else if (t > 160) cc = true }
                        }
                    },
                    onVerticalDrag = { _, d -> t += d }
                )
            }
        ) {
            Wallpaper()
            Home(apps, { app = it }, { drawer = true })
            AnimatedVisibility(drawer, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) { Drawer(apps) { drawer = false; app = it } }
            AnimatedVisibility(cc, enter = slideInVertically { -it }, exit = slideOutVertically { -it }) { ControlCenter { cc = false; if (it != null) app = it } }
            AnimatedVisibility(app != null, enter = scaleIn(initialScale = .3f) + fadeIn(), exit = scaleOut(targetScale = .3f) + fadeOut()) { AppHost(last) { app = null } }
            StatusLayer { cc = !cc }
            AnimatedVisibility(locked, exit = slideOutVertically { -it } + fadeOut()) { Lock { unlock() } }
        }
    }
}

@Composable fun StatusLayer(openCC: () -> Unit) {
    val d = now(); val bat = battery(); val w = Store.weather; val net = netInfo(); val media = rememberMedia()
    var open by remember { mutableStateOf(false) }
    LaunchedEffect(open) { if (open) { delay(3500); open = false } }
    val iw by animateDpAsState(if (open) 300.dp else 112.dp, spring(dampingRatio = .6f))
    val ih by animateDpAsState(if (open) 70.dp else 32.dp, spring(dampingRatio = .6f))
    val time = SimpleDateFormat("H:mm", Locale.getDefault()).format(d)
    Box(Modifier.fillMaxWidth().topSafe().padding(top = 10.dp)) {
        Row(Modifier.align(Alignment.TopStart).padding(start = 26.dp, top = 6.dp).clickable { openCC() }, verticalAlignment = Alignment.CenterVertically) {
            Text(time, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
        Row(Modifier.align(Alignment.TopEnd).padding(end = 22.dp, top = 7.dp).clickable { openCC() }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Ic(if (net.first) Icons.Filled.Wifi else Icons.Filled.SignalCellularAlt, size = 15.dp)
            Text(net.second, color = Color.White, fontSize = 11.sp, maxLines = 1)
            Ic(if (Stat.charging) Icons.Filled.BatteryChargingFull else Icons.Filled.BatteryFull, if (bat < 20 && !Stat.charging) Color(0xFFFF5252) else Color.White, 17.dp)
            Text("$bat%", color = Color.White, fontSize = 11.sp)
        }
        Box(Modifier.align(Alignment.TopCenter).size(iw, ih).clip(RoundedCornerShape(ih / 2)).background(Color.Black).clickable { open = !open }, contentAlignment = Alignment.Center) {
            if (open) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (media != null) { Ic(Icons.Filled.MusicNote, Color(0xFF4DC3FF)); Text(media.title, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 200.dp)) }
                else {
                    Ic(if (Stat.charging) Icons.Filled.BatteryChargingFull else Icons.Filled.BatteryFull, Color(0xFF4CD964)); Text("$bat%", color = Color.White)
                    if (w != null) { Ic(wxVec(w.code), size = 20.dp); Text("${w.temp}°", color = Color.White) }
                    Text(time, color = Color.White)
                }
            }
        }
    }
}

@Composable fun Lock(onUnlock: () -> Unit) {
    val ctx = LocalContext.current; val d = now()
    Box(Modifier.fillMaxSize().background(Color(0x99000000))) {
        Column(Modifier.fillMaxSize().topSafe().padding(top = 80.dp, start = 18.dp, end = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(d), color = Color.White, fontSize = 17.sp)
            Text(SimpleDateFormat("H:mm", Locale.getDefault()).format(d), style = TextStyle(fontSize = 92.sp, fontWeight = FontWeight.ExtraLight, color = Color.White, shadow = Shadow(Color(0xFF8AB0FF), Offset.Zero, 30f)))
            Spacer(Modifier.height(16.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) { MediaCard(); NotifList(4) }
            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 24.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                RoundBtn(if (TorchCtl.on) Icons.Filled.FlashlightOn else Icons.Filled.FlashlightOff, TorchCtl.on) { TorchCtl.toggle(ctx) }
                Row(Modifier.clip(RoundedCornerShape(20.dp)).clickable { onUnlock() }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Ic(Icons.Filled.Lock, Color(0xCCFFFFFF), 16.dp); Spacer(Modifier.width(6.dp)); Text("Upar swipe / tap karo", color = Color(0xCCFFFFFF), fontSize = 13.sp)
                }
                RoundBtn(Icons.Filled.PhotoCamera) { ctx.go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
            }
        }
    }
}

@Composable fun Home(apps: List<App>, open: (String) -> Unit, openDrawer: () -> Unit) {
    val ctx = LocalContext.current
    val pager = rememberPagerState { 2 }
    val fav = remember(apps) {
        val want = listOf("com.google.android.youtube", "com.discord", "com.whatsapp", "com.instagram.android", "com.android.vending", "com.android.chrome", "com.spotify.music", "com.netflix.mediaclient")
        val f = want.mapNotNull { p -> apps.find { it.pkg == p } }
        (f + apps.filter { it !in f }).take(8)
    }
    Column(Modifier.fillMaxSize().topSafe().navigationBarsPadding().padding(top = 50.dp, start = 14.dp, end = 14.dp, bottom = 8.dp)) {
        HorizontalPager(pager, Modifier.weight(1f)) { p -> if (p == 0) PageOne(fav, open) else PageTwo(open) }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
            repeat(2) { Box(Modifier.padding(3.dp).size(7.dp).clip(CircleShape).background(Color.White.copy(alpha = if (pager.currentPage == it) 1f else .35f))) }
        }
        Row(Modifier.align(Alignment.CenterHorizontally).glass(20.dp).clickable { openDrawer() }.padding(horizontal = 22.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Ic(Icons.Filled.Search, Color(0xDDFFFFFF), 16.dp); Spacer(Modifier.width(6.dp)); Text("Search", color = Color(0xDDFFFFFF), fontSize = 13.sp)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().glass(34.dp).padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            listOf("Phone", "Messages").forEach { n -> Box(Modifier.clickable { open(n) }) { MIcon(mapp(n), 52.dp) } }
            Box(Modifier.size(58.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color.White, Color(0xFF4DC3FF), Color(0xFF6A3CFF)))).clickable { open("AI") }, contentAlignment = Alignment.Center) { Ic(Icons.Filled.AutoAwesome, Color(0xFF1A1450), 28.dp) }
            Box(Modifier.clickable { open("Gallery") }) { MIcon(mapp("Gallery"), 52.dp) }
            Box(Modifier.clickable { open("Camera") }) { MIcon(mapp("Camera"), 52.dp) }
        }
    }
}

@Composable fun PageOne(fav: List<App>, open: (String) -> Unit) {
    val d = now(); val w = Store.weather
    val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greet = when { hr < 12 -> "Good Morning"; hr < 17 -> "Good Afternoon"; else -> "Good Evening" }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(SimpleDateFormat("H:mm", Locale.getDefault()).format(d), style = TextStyle(fontSize = 70.sp, fontWeight = FontWeight.ExtraLight, color = Color.White, shadow = Shadow(Color(0xFF8AB0FF), Offset.Zero, 28f)))
                Text(SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(d), color = Color.White)
            }
            Column(Modifier.clickable { open("Weather") }, horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) { Ic(wxVec(w?.code ?: 2), size = 30.dp); Spacer(Modifier.width(6.dp)); Text("${w?.temp ?: "--"}°", fontSize = 30.sp, color = Color.White) }
                Text(w?.let { wxText(it.code) } ?: "Loading…", fontSize = 12.sp, color = Color.White)
                Text(CITY, fontSize = 12.sp, color = Color(0xCCFFFFFF))
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().glass(30.dp).clickable { open("AI") }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color.White, Color(0xFF4DC3FF), Color(0xFF6A3CFF)))))
            Spacer(Modifier.width(12.dp))
            Column { Text("$greet, Vinod", color = Color.White, fontWeight = FontWeight.Bold); Text("Your day is looking great!", color = Color(0xCCFFFFFF), fontSize = 12.sp) }
        }
        Spacer(Modifier.weight(1f))
        Column(Modifier.fillMaxWidth().glass().padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            fav.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { AppIcon(it) }
                    repeat(4 - row.size) { Spacer(Modifier.width(72.dp)) }
                }
            }
        }
    }
}

@Composable fun PageTwo(open: (String) -> Unit) {
    val w = Store.weather; val bat = battery(); val net = netInfo()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.fillMaxWidth().glass().clickable { open("Weather") }.padding(16.dp)) {
            Text("Weather · $CITY", color = Color(0xCCFFFFFF), fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) { Ic(wxVec(w?.code ?: 2), size = 34.dp); Spacer(Modifier.width(8.dp)); Text("${w?.temp ?: "--"}°  ${w?.let { wxText(it.code) } ?: ""}", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light) }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                (w?.days ?: emptyList()).forEach { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(it.name, color = Color.White, fontSize = 12.sp); Ic(wxVec(it.code), size = 22.dp); Text("${it.hi}°/${it.lo}°", color = Color.White, fontSize = 11.sp) } }
            }
        }
        MediaCard()
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f).glass().padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Ic(if (Stat.charging) Icons.Filled.BatteryChargingFull else Icons.Filled.BatteryFull, size = 18.dp); Spacer(Modifier.width(4.dp)); Text("Battery", color = Color(0xCCFFFFFF), fontSize = 12.sp) }; Text("$bat%", color = Color.White, fontSize = 30.sp) }
            Column(Modifier.weight(1f).glass().clickable { open("Speed") }.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Ic(Icons.Filled.Speed, size = 18.dp); Spacer(Modifier.width(4.dp)); Text(net.second, color = Color(0xCCFFFFFF), fontSize = 12.sp) }; Text("Speed test", color = Color.White, fontSize = 20.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f).glass().clickable { open("Notes") }.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Ic(Icons.Filled.EditNote, size = 18.dp); Spacer(Modifier.width(4.dp)); Text("Notes", color = Color.White, fontWeight = FontWeight.Bold) } }
            Column(Modifier.weight(1f).glass().clickable { open("Calculator") }.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Ic(Icons.Filled.Calculate, size = 18.dp); Spacer(Modifier.width(4.dp)); Text("Calculator", color = Color.White, fontWeight = FontWeight.Bold) } }
        }
        NotifList(5)
    }
}
