package com.mikos.launcher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

val LocalApps = staticCompositionLocalOf<List<App>> { emptyList() }

object Recents {
    val list = mutableStateListOf<String>()
    fun add(p: String) { list.remove(p); list.add(0, p); while (list.size > 8) list.removeAt(list.lastIndex) }
}

data class MApp(val name: String, val label: String, val icon: ImageVector, val c1: Color, val c2: Color)

val mikosApps = listOf(
    MApp("Phone", "Phone", Icons.Filled.Call, Color(0xFF34C759), Color(0xFF1F9D55)),
    MApp("Messages", "Messages", Icons.Filled.Chat, Color(0xFF4DA3FF), Color(0xFF2F6BFF)),
    MApp("Camera", "Camera", Icons.Filled.PhotoCamera, Color(0xFF616161), Color(0xFF1B1B1B)),
    MApp("Gallery", "Gallery", Icons.Filled.PhotoLibrary, Color(0xFFFF8A65), Color(0xFFE91E63)),
    MApp("Clock", "Clock", Icons.Filled.Schedule, Color(0xFF455A64), Color(0xFF1C2833)),
    MApp("Notes", "Notes", Icons.Filled.EditNote, Color(0xFFFFD54F), Color(0xFFFFA000)),
    MApp("Calculator", "Calculator", Icons.Filled.Calculate, Color(0xFF616161), Color(0xFF212121)),
    MApp("Weather", "Weather", Icons.Filled.WbSunny, Color(0xFF42A5F5), Color(0xFF1565C0)),
    MApp("Speed", "5G Speed", Icons.Filled.Speed, Color(0xFF7C4DFF), Color(0xFF2F9BFF)),
    MApp("AI", "MIKOS AI", Icons.Filled.AutoAwesome, Color(0xFF6A3CFF), Color(0xFF4DC3FF)),
    MApp("Games", "Games", Icons.Filled.SportsEsports, Color(0xFFFF6B6B), Color(0xFF6A3CFF)),
    MApp("Settings", "Settings", Icons.Filled.Settings, Color(0xFF78909C), Color(0xFF37474F))
)
fun mapp(n: String) = mikosApps.first { it.name == n }

fun Modifier.topSafe(): Modifier = this.windowInsetsPadding(WindowInsets.displayCutout)

@Composable fun Ic(v: ImageVector, tint: Color = Color.White, size: Dp = 24.dp, mod: Modifier = Modifier) { Icon(v, null, mod.size(size), tint) }

@Composable fun MIcon(a: MApp, size: Dp = 54.dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(size * 0.24f)).background(Brush.linearGradient(listOf(a.c1, a.c2))), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x44FFFFFF), Color.Transparent))))
        Ic(a.icon, size = size * 0.52f)
    }
}

@Composable fun AppTile(a: MApp, open: (String) -> Unit) {
    Column(Modifier.width(62.dp).clickable { open(a.name) }, horizontalAlignment = Alignment.CenterHorizontally) {
        MIcon(a); Text(a.label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable fun AppIcon(a: App) {
    val ctx = LocalContext.current
    Column(Modifier.width(72.dp).clickable { Recents.add(a.pkg); ctx.launchPkg(a.pkg) }, horizontalAlignment = Alignment.CenterHorizontally) {
        Image(a.icon, a.label, Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)))
        Text(a.label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable fun RoundBtn(v: ImageVector, on: Boolean = false, f: () -> Unit) {
    Box(
        Modifier.size(52.dp).clip(CircleShape).background(if (on) Brush.linearGradient(listOf(Color(0xFF6A3CFF), Color(0xFF4DC3FF))) else Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x33FFFFFF)))).clickable { f() },
        contentAlignment = Alignment.Center
    ) { Ic(v) }
}

@Composable fun resumeTick(): Int {
    var t by remember { mutableIntStateOf(0) }
    val lo = LocalLifecycleOwner.current
    DisposableEffect(lo) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) t++ }
        lo.lifecycle.addObserver(ob)
        onDispose { lo.lifecycle.removeObserver(ob) }
    }
    return t
}

fun notifAccess(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

@Composable fun NotifCard(n: N) {
    val ctx = LocalContext.current; val apps = LocalApps.current
    val icon = apps.find { it.pkg == n.pkg }?.icon
    Row(Modifier.fillMaxWidth().glass(20.dp).clickable {
        try { n.pi?.send() ?: ctx.launchPkg(n.pkg) } catch (e: Exception) { ctx.launchPkg(n.pkg) }
    }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) Image(icon, null, Modifier.size(34.dp).clip(RoundedCornerShape(9.dp)))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(n.app, color = Color(0xAAFFFFFF), fontSize = 11.sp, maxLines = 1)
            if (n.title.isNotEmpty()) Text(n.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (n.text.isNotEmpty()) Text(n.text, color = Color(0xDDFFFFFF), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (n.clearable) Ic(Icons.Filled.Close, Color(0xAAFFFFFF), 18.dp, Modifier.clickable { Notifs.cancel(n.key) })
    }
}

@Composable fun NotifList(max: Int = 50) {
    val ctx = LocalContext.current
    resumeTick()
    if (!notifAccess(ctx)) {
        Row(Modifier.fillMaxWidth().glass(20.dp).clickable { ctx.go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Ic(Icons.Filled.Notifications); Spacer(Modifier.width(10.dp))
            Text("Real notifications ke liye yaha dabao aur MIKOS ko Notification access do", color = Color.White, fontSize = 13.sp)
        }
    } else if (Notifs.list.isEmpty()) {
        Text("Koi notification nahi", color = Color(0x99FFFFFF), fontSize = 13.sp)
    } else Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Notifs.list.take(max).forEach { NotifCard(it) } }
}

@Composable fun IcBtn(v: ImageVector, f: () -> Unit) { Box(Modifier.size(40.dp).clip(CircleShape).clickable { f() }, contentAlignment = Alignment.Center) { Ic(v, size = 26.dp) } }

@Composable fun MediaCard() {
    val m = rememberMedia() ?: return
    Row(Modifier.fillMaxWidth().glass(22.dp).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Ic(Icons.Filled.MusicNote, Color(0xFF4DC3FF), 28.dp); Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(m.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(m.artist, color = Color(0xAAFFFFFF), fontSize = 12.sp, maxLines = 1)
        }
        IcBtn(Icons.Filled.SkipPrevious) { m.ctl.transportControls.skipToPrevious() }
        IcBtn(if (m.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow) { if (m.playing) m.ctl.transportControls.pause() else m.ctl.transportControls.play() }
        IcBtn(Icons.Filled.SkipNext) { m.ctl.transportControls.skipToNext() }
    }
}
