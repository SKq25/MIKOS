package com.mikos.launcher

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.view.ViewGroup
import android.webkit.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// MIKOS 3D Engine: assets/engine3d.html WebView me chalta hai. AI script server ke /api/script se aata hai (prompt server pe rehta hai).
object ScriptApi {
    fun generate(key: String, lang: String, idea: String, current: String): Pair<String?, String?> {
        if (key.isBlank()) return null to "Pehle Games app me MIKOS access key daalo."
        return try {
            val body = JSONObject().put("lang", lang).put("idea", idea).put("current", current)
            val c = URL("$MIKOS_SERVER/api/script").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 120000
            c.setRequestProperty("content-type", "application/json"); c.setRequestProperty("x-mikos-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            if (c.responseCode != 200) {
                val e = c.errorStream?.bufferedReader()?.readText() ?: ""
                return null to (try { JSONObject(e).getString("error") } catch (x: Exception) { "Error ${c.responseCode}" })
            }
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            j.getString("code") to null
        } catch (e: Exception) { null to "Network error: ${e.message ?: "unknown"}" }
    }
}

class Studio3DBridge(private val scope: CoroutineScope, private val key: String, private val view: () -> WebView?) {
    @JavascriptInterface fun ask(lang: String, idea: String, current: String) {
        scope.launch {
            val (txt, err) = withContext(Dispatchers.IO) { ScriptApi.generate(key, lang, idea, current) }
            val js = "window.onAI(" + JSONObject.quote(txt ?: "") + "," + (if (err != null) JSONObject.quote(err) else "null") + ")"
            view()?.evaluateJavascript(js, null)
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable fun Studio3D(onClose: () -> Unit) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val key = remember { ctx.getSharedPreferences("mikos_ai", Context.MODE_PRIVATE).getString("key", "") ?: "" }
    val html = remember { ctx.assets.open("engine3d.html").bufferedReader().use { it.readText() } }
    var wv by remember { mutableStateOf<WebView?>(null) }
    val pending = remember { arrayOfNulls<ValueCallback<Array<Uri>>>(1) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        pending[0]?.onReceiveValue(uris.toTypedArray()); pending[0] = null
    }
    DisposableEffect(Unit) { onDispose { wv?.apply { stopLoading(); loadUrl("about:blank"); destroy() } } }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.clickable { onClose() }.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                Ic(Icons.Filled.Close, size = 20.dp); Spacer(Modifier.width(4.dp)); Text("Band", color = Color.White, fontSize = 13.sp)
            }
            Text("MIKOS 3D Engine", color = Color(0xAAFFFFFF), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
        }
        AndroidView(modifier = Modifier.weight(1f).fillMaxWidth(), factory = { c ->
            WebView(c).apply {
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                settings.javaScriptEnabled = true; settings.domStorageEnabled = true
                settings.allowFileAccess = false; settings.allowContentAccess = true
                settings.mediaPlaybackRequiresUserGesture = false
                webViewClient = object : WebViewClient() { override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = true }
                webChromeClient = object : WebChromeClient() {
                    override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                        pending[0]?.onReceiveValue(null); pending[0] = cb; picker.launch("*/*"); return true
                    }
                }
                addJavascriptInterface(Studio3DBridge(scope, key) { wv }, "MKA")
                wv = this
                loadDataWithBaseURL("https://game.mikos.local/", html, "text/html", "utf-8", null)
            }
        })
    }
}
