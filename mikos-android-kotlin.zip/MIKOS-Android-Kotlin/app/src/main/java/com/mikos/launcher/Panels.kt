package com.mikos.launcher

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable fun VSlider(v: Float, icon: ImageVector, onV: (Float) -> Unit) {
    var h by remember { mutableFloatStateOf(1f) }
    Box(
        Modifier.width(72.dp).height(170.dp).glass(30.dp).onSizeChanged { h = it.height.toFloat() }
            .pointerInput(Unit) { detectVerticalDragGestures { ch, _ -> onV((1f - ch.position.y / h).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectTapGestures { onV((1f - it.y / h).coerceIn(0f, 1f)) } },
        contentAlignment = Alignment.BottomCenter
    ) {
        Box(Modifier.fillMaxWidth().fillMaxHeight(v.coerceIn(0.02f, 1f)).background(Color(0xDDFFFFFF)))
        Ic(icon, Color(0xFF4DC3FF), 26.dp, Modifier.align(Alignment.TopCenter).padding(top = 12.dp))
    }
}

@Composable fun SquareTile(icon: ImageVector, n: String, on: Boolean, mod: Modifier, f: () -> Unit) {
    Column(
        mod.aspectRatio(1f).glass(24.dp).background(if (on) Brush.linearGradient(listOf(Color(0xAA6A3CFF), Color(0xAA4DC3FF))) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))).clickable { f() },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) { Ic(icon, size = 26.dp); Text(n, color = Color.White, fontSize = 11.sp) }
}

@Composable fun ControlCenter(go: (String?) -> Unit) {
    val ctx = LocalContext.current; val net = netInfo(); val rs = radioState()
    resumeTick()
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val mx = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / mx) }
    var br by remember { mutableFloatStateOf(.8f) }
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val dnd = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
    val air = try { Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (e: Exception) { false }
    Column(
        Modifier.fillMaxSize().background(Color(0xEB0A0C24))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .topSafe().verticalScroll(rememberScrollState()).padding(top = 56.dp, start = 16.dp, end = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f).height(170.dp).glass(30.dp).padding(14.dp), verticalArrangement = Arrangement.SpaceEvenly) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundBtn(Icons.Filled.AirplanemodeActive, air) { ctx.go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
                    RoundBtn(Icons.Filled.SignalCellularAlt, !net.first && net.second != "No network") { ctx.go(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundBtn(Icons.Filled.Wifi, rs.first) { toggleWifi(ctx) }
                    RoundBtn(Icons.Filled.Bluetooth, rs.second) { toggleBt(ctx) }
                }
            }
            VSlider(br, Icons.Filled.LightMode) { br = it; (ctx as? Activity)?.window?.let { win -> val a = win.attributes; a.screenBrightness = it.coerceAtLeast(.1f); win.attributes = a } }
            VSlider(vol, Icons.Filled.VolumeUp) { vol = it; am.setStreamVolume(AudioManager.STREAM_MUSIC, (it * mx).toInt(), 0) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SquareTile(if (TorchCtl.on) Icons.Filled.FlashlightOn else Icons.Filled.FlashlightOff, "Torch", TorchCtl.on, Modifier.weight(1f)) { TorchCtl.toggle(ctx) }
            SquareTile(Icons.Filled.DarkMode, "Focus", dnd, Modifier.weight(1f)) { ctx.go(Intent(Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS)) }
            SquareTile(Icons.Filled.Timer, "Timer", false, Modifier.weight(1f)) { ctx.go(Intent(AlarmClock.ACTION_SET_TIMER)) }
            SquareTile(Icons.Filled.PhotoCamera, "Camera", false, Modifier.weight(1f)) { go("Camera") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf("Calculator", "Notes", "Speed", "AI").forEach { n -> SquareTile(mapp(n).icon, mapp(n).label.take(8), false, Modifier.weight(1f)) { go(n) } }
        }
        MediaCard()
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Notifications", color = Color.White, fontWeight = FontWeight.Bold)
            if (Notifs.list.isNotEmpty()) Text("Clear all", color = Color(0xFF4DC3FF), modifier = Modifier.clickable { Notifs.clearAll() }.padding(6.dp))
        }
        NotifList()
        Text("Band karo", color = Color(0xCCFFFFFF), modifier = Modifier.align(Alignment.CenterHorizontally).clickable { go(null) }.padding(10.dp))
    }
}

@Composable fun Drawer(apps: List<App>, open: (String?) -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = remember(q, apps) { apps.filter { it.label.contains(q, true) } }
    val rec = Recents.list.mapNotNull { p -> apps.find { it.pkg == p } }
    Column(Modifier.fillMaxSize().background(Color(0xF2070920)).topSafe().navigationBarsPadding().padding(top = 56.dp, start = 14.dp, end = 14.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("App Library search…") }, singleLine = true, shape = RoundedCornerShape(26.dp))
        Spacer(Modifier.height(12.dp))
        if (q.isEmpty()) {
            Text("MIKOS", color = Color.White, fontWeight = FontWeight.SemiBold)
            Column(Modifier.padding(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                mikosApps.chunked(5).forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { row.forEach { AppTile(it) { n -> open(n) } } } }
            }
            if (rec.isNotEmpty()) {
                Text("Recent", color = Color.White, fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) { rec.take(4).forEach { AppIcon(it) } }
            }
        }
        LazyVerticalGrid(GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(14.dp)) { items(list, key = { it.pkg }) { AppIcon(it) } }
    }
}
