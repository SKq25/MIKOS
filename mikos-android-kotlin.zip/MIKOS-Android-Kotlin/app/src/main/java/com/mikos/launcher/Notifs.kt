package com.mikos.launcher

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay

data class N(val key: String, val app: String, val pkg: String, val title: String, val text: String, val time: Long, val pi: PendingIntent?, val clearable: Boolean)

object Notifs {
    var list by mutableStateOf<List<N>>(emptyList())
    var svc: MikosNotifService? = null
    fun cancel(k: String) { svc?.cancelNotification(k) }
    fun clearAll() { svc?.cancelAllNotifications() }
    fun update(ctx: Context, l: List<StatusBarNotification>) {
        val pm = ctx.packageManager
        list = l.filter { it.packageName != ctx.packageName && (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
            .sortedByDescending { it.postTime }
            .map {
                val e = it.notification.extras
                val label = try { pm.getApplicationLabel(pm.getApplicationInfo(it.packageName, 0)).toString() } catch (x: Exception) { it.packageName }
                N(it.key, label, it.packageName, e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "", e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "", it.postTime, it.notification.contentIntent, it.isClearable)
            }
    }
}

class MikosNotifService : NotificationListenerService() {
    private fun refresh() { Notifs.update(this, try { activeNotifications.toList() } catch (e: Exception) { emptyList() }) }
    override fun onListenerConnected() { Notifs.svc = this; refresh() }
    override fun onListenerDisconnected() { Notifs.svc = null }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { refresh() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refresh() }
}

class MediaInfo(val title: String, val artist: String, val playing: Boolean, val ctl: MediaController)

fun readMedia(c: Context): MediaInfo? {
    return try {
        val msm = c.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val ctl = msm.getActiveSessions(ComponentName(c, MikosNotifService::class.java)).firstOrNull() ?: return null
        val md = ctl.metadata
        MediaInfo(md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Playing", md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "", ctl.playbackState?.state == PlaybackState.STATE_PLAYING, ctl)
    } catch (e: Exception) { null }
}

@Composable fun rememberMedia(): MediaInfo? {
    val ctx = LocalContext.current
    var m by remember { mutableStateOf<MediaInfo?>(null) }
    LaunchedEffect(Unit) { while (true) { m = readMedia(ctx); delay(1500) } }
    return m
}
