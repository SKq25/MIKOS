package com.mikos.launcher

import android.annotation.SuppressLint
import android.content.Context
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// MIKOS Game Engine: AI se game banta hai (server pe), phone me WebView me chalta hai. MIKOS access key zaroori.
class SavedGame(val id: Long, var title: String, var prompt: String, h: String) { var html by mutableStateOf(h) }

object GameApi {
    // Returns Pair(html, error)
    fun generate(key: String, history: List<Pair<String, String>>): Pair<String?, String?> {
        return try {
            val arr = JSONArray()
            history.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }
            val c = URL("$MIKOS_SERVER/api/game").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 240000
            c.setRequestProperty("content-type", "application/json"); c.setRequestProperty("x-mikos-key", key)
            c.outputStream.use { it.write(JSONObject().put("messages", arr).toString().toByteArray()) }
            if (c.responseCode != 200) {
                val e = c.errorStream?.bufferedReader()?.readText() ?: ""
                val m = try { JSONObject(e).getString("error") } catch (x: Exception) { "Error ${c.responseCode}" }
                return null to m
            }
            JSONObject(c.inputStream.bufferedReader().readText()).getString("html") to null
        } catch (e: Exception) { null to "Network error: ${e.message ?: "unknown"}" }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable fun GameView(html: String, modifier: Modifier = Modifier) {
    var wv by remember { mutableStateOf<WebView?>(null) }
    DisposableEffect(Unit) { onDispose { wv?.apply { stopLoading(); loadUrl("about:blank"); destroy() } } }
    AndroidView(modifier = modifier, factory = { c ->
        WebView(c).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.allowFileAccess = false; settings.allowContentAccess = false
            settings.mediaPlaybackRequiresUserGesture = false
            // AI-generated code: koi bhi link/navigation block
            webViewClient = object : WebViewClient() { override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = true }
            wv = this
        }
    }, update = { v ->
        if (v.tag != html) { v.tag = html; v.loadDataWithBaseURL("https://game.mikos.local/", html, "text/html", "utf-8", null) }
    })
}

@Composable fun GameStudio() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val sp = remember { ctx.getSharedPreferences("mikos_ai", Context.MODE_PRIVATE) }
    val gp = remember { ctx.getSharedPreferences("mikos_games", Context.MODE_PRIVATE) }
    var key by remember { mutableStateOf(sp.getString("key", "") ?: "") }
    val games = remember {
        mutableStateListOf<SavedGame>().apply {
            try { val a = JSONArray(gp.getString("list", "[]")); for (i in 0 until a.length()) { val o = a.getJSONObject(i); add(SavedGame(o.getLong("id"), o.getString("t"), o.getString("p"), o.getString("h"))) } } catch (_: Exception) {}
        }
    }
    fun persist() { val a = JSONArray(); games.forEach { a.put(JSONObject().put("id", it.id).put("t", it.title).put("p", it.prompt).put("h", it.html)) }; gp.edit().putString("list", a.toString()).apply() }

    var prompt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf<SavedGame?>(null) }
    var edit by remember { mutableStateOf("") }
    var showEdit by remember { mutableStateOf(false) }
    var studio3d by remember { mutableStateOf(false) }

    fun create(idea: String) {
        if (idea.isBlank() || busy) return
        busy = true; status = "AI game bana raha hai… (30-90 sec)"
        scope.launch {
            val (html, err) = withContext(Dispatchers.IO) { GameApi.generate(key, listOf("user" to idea.trim())) }
            busy = false
            if (html == null) { status = err ?: "Error"; return@launch }
            val g = SavedGame(System.currentTimeMillis(), idea.trim().take(28), idea.trim(), html)
            games.add(0, g); while (games.size > 15) games.removeAt(games.lastIndex); persist()
            status = ""; prompt = ""; playing = g
        }
    }
    fun improve(g: SavedGame, change: String) {
        if (change.isBlank() || busy) return
        busy = true; status = "AI game update kar raha hai…"; showEdit = false
        scope.launch {
            val hist = listOf("user" to g.prompt, "assistant" to "```html\n${g.html}\n```", "user" to "Is game me ye badlav karo (poori updated game wapas do): ${change.trim()}")
            val (html, err) = withContext(Dispatchers.IO) { GameApi.generate(key, hist) }
            busy = false
            if (html == null) { status = err ?: "Error"; return@launch }
            g.html = html; persist(); status = ""; edit = ""
        }
    }

    if (studio3d) { Studio3D { studio3d = false }; return }
    val p = playing
    if (p != null) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.clickable { playing = null; showEdit = false }.padding(4.dp), verticalAlignment = Alignment.CenterVertically) { Ic(Icons.Filled.Close, size = 20.dp); Spacer(Modifier.width(4.dp)); Text("Band", color = Color.White, fontSize = 13.sp) }
                Text(p.title, color = Color(0xAAFFFFFF), fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                Row(Modifier.clickable { showEdit = !showEdit }.padding(4.dp), verticalAlignment = Alignment.CenterVertically) { Ic(Icons.Filled.AutoAwesome, Color(0xFF4DC3FF), 18.dp); Spacer(Modifier.width(4.dp)); Text("AI se badlo", color = Color(0xFF4DC3FF), fontSize = 13.sp) }
            }
            if (showEdit) Row(Modifier.padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(edit, { edit = it }, Modifier.weight(1f), maxLines = 3, placeholder = { Text("Kya badalna hai? jaise: speed kam karo, boss add karo") }, shape = RoundedCornerShape(20.dp))
                IcBtn(Icons.Filled.Send) { improve(p, edit) }
            }
            if (busy || status.isNotEmpty()) Text(status, color = Color(0xFFFFC857), fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
            GameView(p.html, Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(14.dp)))
        }
        return
    }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Ic(Icons.Filled.SportsEsports, Color(0xFF4DC3FF), 30.dp); Spacer(Modifier.width(8.dp))
            Column { Text("MIKOS Game Engine", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("Apna game idea likho, AI poora game bana dega", color = Color(0xAAFFFFFF), fontSize = 12.sp) }
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF6A3CFF)).clickable { studio3d = true }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Ic(Icons.Filled.ViewInAr, Color.White, 26.dp); Spacer(Modifier.width(8.dp))
            Column { Text("3D Engine Studio", color = Color.White, fontWeight = FontWeight.Bold); Text("C# / Java / Blueprint + asset import + AI", color = Color(0xCCFFFFFF), fontSize = 11.sp) }
        }
        if (key.isBlank()) {
            var k by remember { mutableStateOf("") }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF151C58)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Game Engine chalane ke liye MIKOS access key chahiye.", color = Color.White, fontSize = 13.sp)
                OutlinedTextField(k, { k = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Access key (MIKOS-XXXX-XXXX-XXXX)") })
                Text("Save karo", color = Color(0xFF4DC3FF), fontWeight = FontWeight.Bold, modifier = Modifier.clickable { if (k.isNotBlank()) { key = k.trim(); sp.edit().putString("key", key).apply() } }.padding(4.dp))
            }
        } else {
            OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth(), maxLines = 4, placeholder = { Text("jaise: space shooter jisme asteroids aur boss ho") }, shape = RoundedCornerShape(20.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Endless runner", "Snake neon", "Flappy style", "Space shooter", "Brick breaker").forEach {
                    Text(it, color = Color.White, fontSize = 12.sp, modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF151C58)).clickable { prompt = it + " game" }.padding(horizontal = 12.dp, vertical = 8.dp))
                }
            }
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(if (busy) Color(0xFF2A3380) else Color(0xFF3B6BFF)).clickable(enabled = !busy) { create(prompt) }.padding(14.dp), contentAlignment = Alignment.Center) {
                Text(if (busy) "Ban raha hai…" else "Game banao", color = Color.White, fontWeight = FontWeight.Bold)
            }
            if (status.isNotEmpty()) Text(status, color = Color(0xFFFFC857), fontSize = 12.sp)
        }
        Text("Meri games", color = Color(0xAAFFFFFF), fontSize = 12.sp)
        if (games.isEmpty()) Text("Abhi koi game nahi. Upar idea likho.", color = Color(0x88FFFFFF), fontSize = 13.sp)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(games, key = { it.id }) { g ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF1C2670)).clickable { playing = g }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Ic(Icons.Filled.PlayArrow, Color(0xFF3DDC97), 26.dp); Spacer(Modifier.width(8.dp))
                    Text(g.title, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1)
                    Ic(Icons.Filled.Delete, Color(0xFFFF8A8A), 22.dp, Modifier.clickable { games.remove(g); persist(); Toast.makeText(ctx, "Game delete ho gayi", Toast.LENGTH_SHORT).show() })
                }
            }
        }
    }
}
