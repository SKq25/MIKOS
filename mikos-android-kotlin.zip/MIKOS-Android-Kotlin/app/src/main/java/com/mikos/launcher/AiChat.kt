package com.mikos.launcher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// Apne server ka address yahan daalo (bina last slash ke), jaise "https://ai.mikos.in" ya "http://192.168.1.5:3000"
const val MIKOS_SERVER = BuildConfig.MIKOS_SERVER

const val DEFAULT_SYS = "You are MIKOS AI, the assistant built into the MIKOS phone launcher. You are an expert programmer and a helpful general assistant. " +
    "Reply in the same language the user writes in (Hinglish is fine). For any code, always use fenced markdown code blocks with a language tag, " +
    "explain briefly, point out bugs, and keep answers phone-friendly. Ask a short question if the request is unclear."

class Msg(val role: String, t: String) { var text by mutableStateOf(t) }

object Ai {
    @Volatile var conn: HttpURLConnection? = null
    @Volatile var stopped = false

    // MIKOS server (OpenRouter proxy). User ko koi API key nahi chahiye, sirf MIKOS access key.
    // Returns error text or null on success.
    fun stream(key: String, system: String, msgs: List<Pair<String, String>>, onDelta: (String) -> Unit): String? {
        stopped = false
        return try {
            val arr = JSONArray()
            msgs.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }
            val body = JSONObject().put("stream", true).put("system", system).put("messages", arr)
            val c = URL("$MIKOS_SERVER/api/chat").openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 90000
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-mikos-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            if (c.responseCode != 200) {
                val e = c.errorStream?.bufferedReader()?.readText() ?: ""
                val m = try { JSONObject(e).getString("error") } catch (x: Exception) { e.take(200) }
                return if (m.isNotBlank()) m else "Error ${c.responseCode}"
            }
            c.inputStream.bufferedReader().useLines { lines ->
                for (l in lines) {
                    if (!l.startsWith("data:")) continue
                    val d = l.removePrefix("data:").trim()
                    if (d.isEmpty() || d == "[DONE]") continue
                    try {
                        val t = JSONObject(d).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")?.optString("content", "") ?: ""
                        if (t.isNotEmpty()) onDelta(t)
                    } catch (_: Exception) {}
                }
            }
            null
        } catch (e: Exception) { if (stopped) null else "Network error: ${e.message ?: "unknown"}" }
        finally { conn = null }
    }
}

sealed class Seg { data class T(val s: String) : Seg(); data class C(val lang: String, val code: String) : Seg() }

fun parseSegs(s: String): List<Seg> {
    val out = ArrayList<Seg>(); var i = 0
    while (true) {
        val st = s.indexOf("```", i)
        if (st < 0) { out.add(Seg.T(s.substring(i))); break }
        out.add(Seg.T(s.substring(i, st)))
        val nl = s.indexOf('\n', st + 3)
        if (nl < 0) { out.add(Seg.C("", s.substring(st + 3))); break }
        val lang = s.substring(st + 3, nl).trim()
        val en = s.indexOf("```", nl + 1)
        if (en < 0) { out.add(Seg.C(lang, s.substring(nl + 1))); break }
        out.add(Seg.C(lang, s.substring(nl + 1, en).trimEnd('\n')))
        i = en + 3
    }
    return out.filter { !(it is Seg.T && it.s.isBlank()) }
}

fun inlineMd(src: String): AnnotatedString {
    val s = src.replace(Regex("(?m)^#{1,6}\\s*(.+)$"), "**$1**")
    return buildAnnotatedString {
        var i = 0
        while (i < s.length) {
            if (s.startsWith("**", i)) {
                val e = s.indexOf("**", i + 2)
                if (e > 0) { pushStyle(SpanStyle(fontWeight = FontWeight.Bold)); append(s.substring(i + 2, e)); pop(); i = e + 2; continue }
            }
            if (s[i] == '`') {
                val e = s.indexOf('`', i + 1)
                if (e > 0) { pushStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x44FFFFFF))); append(s.substring(i + 1, e)); pop(); i = e + 1; continue }
            }
            append(s[i]); i++
        }
    }
}

@Composable fun CodeBlock(lang: String, code: String) {
    val clip = LocalClipboardManager.current; val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF070B26))) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF151C58)).padding(horizontal = 10.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(lang.ifEmpty { "code" }, color = Color(0xFF4DC3FF), fontSize = 11.sp)
            Row(Modifier.clickable { clip.setText(AnnotatedString(code)); Toast.makeText(ctx, "Code copy ho gaya", Toast.LENGTH_SHORT).show() }.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                Ic(Icons.Filled.ContentCopy, Color(0xFF4DC3FF), 14.dp); Spacer(Modifier.width(4.dp)); Text("Copy", color = Color(0xFF4DC3FF), fontSize = 11.sp)
            }
        }
        Text(code, color = Color(0xFFE6EDFF), fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.horizontalScroll(rememberScrollState()).padding(10.dp))
    }
}

@Composable fun Bubble(m: Msg, busy: Boolean) {
    val me = m.role == "user"
    val clip = LocalClipboardManager.current
    Box(Modifier.fillMaxWidth(), contentAlignment = if (me) Alignment.CenterEnd else Alignment.CenterStart) {
        Column(
            Modifier.widthIn(max = if (me) 290.dp else 340.dp).clip(RoundedCornerShape(18.dp)).background(if (me) Color(0xFF3B6BFF) else Color(0xFF1C2670)).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (me) Text(m.text, color = Color.White)
            else if (m.text.isBlank()) Text(if (busy) "…" else "", color = Color.White)
            else {
                parseSegs(m.text).forEach { sg ->
                    when (sg) {
                        is Seg.T -> Text(inlineMd(sg.s.trim('\n')), color = Color.White, fontSize = 14.sp)
                        is Seg.C -> CodeBlock(sg.lang, sg.code)
                    }
                }
                if (!busy) Row(Modifier.clickable { clip.setText(AnnotatedString(m.text)) }, verticalAlignment = Alignment.CenterVertically) {
                    Ic(Icons.Filled.ContentCopy, Color(0x99FFFFFF), 13.dp); Spacer(Modifier.width(4.dp)); Text("Copy reply", color = Color(0x99FFFFFF), fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable fun MikosAi() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val sp = remember { ctx.getSharedPreferences("mikos_ai", Context.MODE_PRIVATE) }
    var key by remember { mutableStateOf(sp.getString("key", "") ?: "") }
    var sys by remember { mutableStateOf(sp.getString("sys", DEFAULT_SYS) ?: DEFAULT_SYS) }
    val msgs = remember {
        mutableStateListOf<Msg>().apply {
            try { val a = JSONArray(sp.getString("chat", "[]")); for (i in 0 until a.length()) { val o = a.getJSONObject(i); add(Msg(o.getString("r"), o.getString("t"))) } } catch (_: Exception) {}
        }
    }
    var inp by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }; var dlg by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    val ls = rememberLazyListState()
    fun saveChat() { val a = JSONArray(); msgs.forEach { a.put(JSONObject().put("r", it.role).put("t", it.text)) }; sp.edit().putString("chat", a.toString()).apply() }
    fun stop() { Ai.stopped = true; Ai.conn?.disconnect(); job?.cancel(); busy = false; saveChat() }
    fun send(t: String) {
        if (t.isBlank() || busy) return
        msgs.add(Msg("user", t.trim()))
        val ai = Msg("assistant", ""); msgs.add(ai); busy = true; saveChat()
        if (key.isBlank()) {
            job = scope.launch { delay(400); ai.text = aiReply(t) + "\n\n(Offline demo. Asli AI ke liye upar gear icon se MIKOS access key daalo.)"; busy = false; saveChat() }
            return
        }
        val hist = msgs.dropLast(1).takeLast(30).filter { it.text.isNotBlank() }.map { it.role to it.text }.dropWhile { it.first != "user" }
        job = scope.launch(Dispatchers.IO) {
            val err = Ai.stream(key, sys, hist) { d -> ai.text += d }
            if (err != null) ai.text = (if (ai.text.isBlank()) "" else ai.text + "\n\n") + err
            busy = false; saveChat()
        }
    }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { inp = it }
    }
    LaunchedEffect(msgs.size, msgs.lastOrNull()?.text?.length) { if (msgs.isNotEmpty()) ls.scrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(if (key.isBlank()) "Offline demo (access key nahi)" else "MIKOS AI", color = Color(0xAAFFFFFF), fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Ic(Icons.Filled.Add, mod = Modifier.clickable { stop(); msgs.clear(); saveChat() })
                Ic(Icons.Filled.Settings, mod = Modifier.clickable { dlg = true })
            }
        }
        if (msgs.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Ic(Icons.Filled.AutoAwesome, Color(0xFF4DC3FF), 44.dp)
                Text("MIKOS AI", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                Text("Coding, debugging, writing, sawaal: kuch bhi pucho", color = Color(0xAAFFFFFF), fontSize = 13.sp)
            }
        } else {
            LazyColumn(Modifier.weight(1f), state = ls, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(msgs.size) { i -> Bubble(msgs[i], busy && i == msgs.lastIndex) }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Python me quicksort likho", "Kotlin me REST API call kaise karu?", "Mera code debug karo", "Explain Big-O simply", "Plan my day").forEach {
                Text(it, color = Color.White, fontSize = 12.sp, modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF151C58)).clickable { send(it) }.padding(horizontal = 12.dp, vertical = 8.dp))
            }
        }
        Row(Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(inp, { inp = it }, Modifier.weight(1f), maxLines = 4, placeholder = { Text("Message ya code likho…") }, shape = RoundedCornerShape(24.dp))
            Spacer(Modifier.width(4.dp))
            IcBtn(Icons.Filled.Mic) {
                try { voice.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)) }
                catch (e: Exception) { Toast.makeText(ctx, "Voice input is phone me nahi mila", Toast.LENGTH_SHORT).show() }
            }
            if (busy) IcBtn(Icons.Filled.Stop) { stop() } else IcBtn(Icons.Filled.Send) { send(inp); inp = "" }
        }
    }
    if (dlg) AlertDialog(
        onDismissRequest = { dlg = false },
        title = { Text("MIKOS Access Key") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(key, { key = it }, label = { Text("Access key (MIKOS-XXXX-XXXX-XXXX)") }, singleLine = true)
                OutlinedTextField(sys, { sys = it }, label = { Text("System prompt") }, maxLines = 6)
                Text("AI chalane ke liye MIKOS access key chahiye. Key MIKOS admin se milti hai.", fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = { key = key.trim(); sp.edit().putString("key", key).putString("sys", sys).apply(); dlg = false }) { Text("Save") } },
        dismissButton = { TextButton(onClick = { key = ""; sp.edit().remove("key").apply(); dlg = false }) { Text("Key hatao") } }
    )
}
